::mods_registerMod("mod_breditor", 1.0, "Breditor");

::mods_queue("mod_breditor", null, function() {
/* 	::mods_registerJS("world_breditor_screen.js");
 	::mods_registerCSS("world_breditor_screen.css"); */

	
	::mods_hookNewObjectOnce("states/world_state", function(o) {
	  local ws_init_ui = o.onInitUI;
	  o.onInitUI = function()
	  {
		ws_init_ui();
		this.m.WorldBreditorScreen <- this.new("scripts/ui/screens/world/world_breditor_screen");
		this.m.WorldBreditorScreen.setOnClosePressedListener(this.town_screen_main_dialog_module_onLeaveButtonClicked.bindenv(this));
		this.initLoadingScreenHandler();
	  }
	});
	
	::mods_hookNewObjectOnce("states/world_state", function(o) {
	  local ws_destroy_ui = o.onDestroyUI;
	  o.onDestroyUI = function()
	  {
		ws_destroy_ui();
		this.m.WorldBreditorScreen.destroy();
		this.m.WorldBreditorScreen = null;
	  }
	});
	
	::mods_hookNewObjectOnce("ui/screens/tooltip/tooltip_events", function(o) {
	  local queryTooltipData = o.general_queryUIElementTooltipData;
	  o.general_queryUIElementTooltipData = function(entityId, elementId, elementOwner)
	  {
		local tooltip = queryTooltipData(entityId, elementId, elementOwner);
		if(tooltip != null) return tooltip;
		if(elementId == "breditor-talent-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Talent"
			},
			{
			  id = 2,
			  type = "description",
			  text = "Click to loop through talent levels. 0-1-2-3-0-1-2-3-..."
			},
		  ];
		}
/* 		else if(elementId == "breditor-stats-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Attributes"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Current value of the respective attribute (without any bonuses from traits or equipment) // maximum possible starting value of the respective attribute for a character of this particular background."
			}, 
		  ];
		} */
		else if(elementId == "breditor-xp-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "+1 Level"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Gives the current bro the amount of XP it takes to reach the next level."
			}, 
		  ];
		}
		else if(elementId == "breditor-pp-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Perk points"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "This is your perk points."
			}, 
		  ];
		}
		else if(elementId == "breditor-op-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "OP"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Click to drink Oblivion Potion."
			}, 
		  ];
		}
		else if(elementId == "breditor-yf-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Youth Fountain"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Click to drink water from the Fountain of Youth. It will heal your injuries and improve your mood."
			}, 
		  ];
		}
		else if(elementId == "breditor-bg-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Backgrounds"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Switches the trait panel to background mode that will allow you to change the background. Can be switched back too."
			}, //\n[b][color=" + this.Const.UI.Color.NegativeValue + "]Warning! Changing background may change your level, even reduce it. That is just how some backgrounds work.[/color][/b]
		  ];
		}
		else if(elementId == "breditor-background-tooltip")
		{
		  local bgtemp = this.new(elementOwner);
		  return [
			{
			  id = 1,
			  type = "title",
			  text = bgtemp.m.Name,
			},
 			{
			  id = 2,
			  type = "description",
			  text = bgtemp.m.BackgroundDescription,
			}, 
		  ];
		}
		else if(elementId == "breditor-nicategory-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Category of Named Items"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Choose the category of named items."
			}, 
		  ];
		}
		else if(elementId == "breditor-niupdateimage-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Reroll"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Rerolls the item (can be used as first step to find preferred appearance)."
			}, 
		  ];
		}
		else if(elementId == "breditor-nifinalize-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Add"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Adds the current item to your inventory."
			}, 
		  ];
		}
		else if(elementId == "breditor-partystrength-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Party Strength"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Calculates your:\n- Party Strength\n- Contract Difficulty Multiplier\n- Enemy Party Difficulty Multiplier"
			}, 
		  ];
		}
		else if(elementId == "breditor-mirrorbattle-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Mirror Battle"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Fight a clone of your party!\n(Not intended for actual gameplay, just for testing/fun)"
			}, 
		  ];
		}
		else if(elementId == "breditor-haircolor-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Hair Color"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Unrelated to Export-Import feature. If you paste (CTRL+V) or type a 6-character color code into the same input window as for export-import and then press this button, it will dye the hair of the current bro respectively. \nHair color cannot be exported, imported or undone, it can only be replaced with another dye. Dye works as the second layer on top of the color you chose at barber\'s, so you can't dye black hair white (using white color ffffff = no dye at all)."
			}, 
		  ];
		}
		else if(elementId == "breditor-beardcolor-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Beard Color"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Unrelated to Export-Import feature. If you paste (CTRL+V) or type a 6-character color code into the same input window as for export-import and then press this button, it will dye the beard of the current bro respectively. \nBeard color cannot be exported, imported or undone, it can only be replaced with another dye. Dye works as the second layer on top of the color you chose at barber\'s, so you can't dye black beard white (using white color ffffff = no dye at all)."
			}, 
		  ];
		}
		else if(elementId == "breditor-impexpstats-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Export Main Stats"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Yes or No - defines if the export string contains info about the [b][color=" + this.Const.UI.Color.PositiveValue + "]main[/color][/b] stats of your current bro (in particular, export-import affects attributes, traits, perks, level, experience, appearance, talents). Click to change."
			}, 
		  ];
		}
		else if(elementId == "breditor-impexplifestats-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Export Lifetime Statistics"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Yes or No - defines if the export string contains info about the lifetimes [b][color=" + this.Const.UI.Color.PositiveValue + "]statistics[/color][/b] of your bro - the amount of kills, the number of battles etc. Click to change."
			}, 
		  ];
		}
		else if(elementId == "breditor-impexpgear-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Export Equipment"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Yes or No - defines if the export string contains info about the current [b][color=" + this.Const.UI.Color.PositiveValue + "]equipment[/color][/b] of your bro. It only saves standard characteristics of large categories of items, does not save exceptional properties of exceptional items. Click to change."
			}, 
		  ];
		}
		else if(elementId == "breditor-broexport-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Export"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Press to generate a string with information about the current bro. Then click on the field with the string and press CTRL+A followed by CTRL+C to save it to clipboard."
			}, 
		  ];
		}
		else if(elementId == "breditor-broimport-tooltip")
		{
		  return [
			{
			  id = 1,
			  type = "title",
			  text = "Import"
			},
 			{
			  id = 2,
			  type = "description",
			  text = "Before using it, use CTRL+A followed by CTRL+V to paste a string with information about a bro into the respective field above (if it does not have a required string yet). [b][color=" + this.Const.UI.Color.NegativeValue + "]Make sure there are no other characters in that field, only the string as-is.[/color][/b]\nThen press this button and your currently selected bro will be replaced.\n[b][color=" + this.Const.UI.Color.NegativeValue + "]It is not recommended to export-import bros between different versions of the game, let alone between different modded versions.[/color][/b]"
			}, 
		  ];
		}
		return null;
	  }
	});
	
	::mods_hookNewObjectOnce("states/world_state", function(o) {
	  local keyHandler = o.helper_handleContextualKeyInput;
	  o.helper_handleContextualKeyInput = function(key)
	  {
		if(!keyHandler(key) && key.getState() == 0)
		{
		  if (key.getKey() == 34 && key.getModifier() == 1) //SHIFT + X
			if (!this.m.MenuStack.hasBacksteps() && !this.m.CharacterScreen.isVisible() && !this.m.WorldTownScreen.isVisible() && !this.m.EventScreen.isVisible() && !this.m.EventScreen.isAnimating())
			{
				this.setAutoPause(true);
				this.m.CustomZoom = this.World.getCamera().Zoom;
				this.World.getCamera().zoomTo(1.0, 4.0);
				this.Tooltip.hide();
				this.m.WorldScreen.hide();
				this.m.WorldBreditorScreen.show();
				this.Cursor.setCursor(this.Const.UI.Cursor.Hand);
				this.m.MenuStack.push(function ()
				{
					this.World.getCamera().zoomTo(this.m.CustomZoom, 4.0);
					this.m.WorldBreditorScreen.hide();
					this.m.WorldScreen.show();
					this.Cursor.setCursor(this.Const.UI.Cursor.Hand);
					this.setAutoPause(false);
				}, function ()
				{
					return !this.m.RelationsScreen.isAnimating();
				});
				return true;
			}
		}
	  }
	});
	
	
	
	
});


